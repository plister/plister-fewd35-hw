$(document).ready(function() {
$("#city-form").submit(function(event) {
// Because it's a form, needs to be a "submit" method. Added the id "city-form".

  event.preventDefault();
//event.preventDefault() stops page from defaulting to the top of the page
  //chain .trim to .val to ignore spaces before or after text entered
    /* Created a variable "cityName" so that when "city-type" in the form field equals one of the city names or abbreviations within each statement, the corresponding background image will be called. */
  var cityName = $("#city-type").val().trim();
/* when listing different cityName options, is it a better practice to put each name on a different line to keep it cleaner? */
if (cityName === "NYC" || cityName === "New York City" || cityName === "NY" || cityName ==="nyc" || cityName === "ny" || cityName === "new york city" || cityName === "New York" || cityName === "new york") {
  //changes background image to NYC jpg when above names are input
  /* When using .css method, think of it like applying styles - need to include the property and the value in the same parentheses */
  $("body").css("background-image", "url('images/nyc.jpg')");
  //Resets placeholder text to "Enter city name..."
  $("#city-form")[0].reset();
} else if (cityName === "San Francisco" || cityName === "SF" || cityName === "san francisco" || cityName === "sf" || cityName === "Bay Area" || cityName === "bay area") {
  //changes background image to SF jpg when above names are input
  $("body").css("background-image", "url('images/sf.jpg')");
  //Resets placeholder text to "Enter city name..."
  $("#city-form")[0].reset();
} else if (cityName === "LA" || cityName === "Los Angeles" || cityName === "la" || cityName === "los angeles" || cityName === "LAX" || cityName === "lax") {
  //changes background image to LA jpg when above names are input
  $("body").css("background-image", "url('images/la.jpg')");
  //Resets placeholder text to "Enter city name..."
  $("#city-form")[0].reset();
} else if (cityName === "Sydney" || cityName === "sydney" || cityName === "SYD" || cityName === "syd") {
  //changes background image to Sydney jpg when above names are input
  $("body").css("background-image", "url('images/sydney.jpg')");
  //Resets placeholder text to "Enter city name..."
  $("#city-form")[0].reset();
} else if (cityName === "Austin" || cityName === "ATX" || cityName === "austin" || cityName === "atx") {
  //changes background image to Austin jpg when above names are input
  $("body").css("background-image", "url('images/austin.jpg')");
  //Resets placeholder text to "Enter city name..."
  $("#city-form")[0].reset();
} else {
  //creates an alert box when the city name that's input is not recognized as one of the above
  alert("Enter a different city.")
}
});
});

/*Alternative way to reset text:
    $("input[type='text']").val("") */

/* Alternative approach to setting this up is using addClass/removeClass, but if I go that route, I would need to addClass and include removeClass for all other classes/background-images */
