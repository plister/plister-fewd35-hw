$(".sign-up-container").click(function() {
  alert("We're not ready for sign-ups...yet.");
});

$(document).ready(function(){
    $(".read-1").click(function(event){
        event.preventDefault();
        $(".blog-text-hidden-1").slideToggle(250);
        $(".read-more-text-1").toggleClass("hide");
        $(".read-less-text-1").toggleClass("hide");
    });
});


$(document).ready(function(){
    $(".read-2").click(function(event){
        event.preventDefault();
        $(".blog-text-hidden-2").slideToggle(250);
        $(".read-more-text-2").toggleClass("hide");
        $(".read-less-text-2").toggleClass("hide");
    });
});
// Another way I saw was by changing the actual text with html to "Read Less"...
