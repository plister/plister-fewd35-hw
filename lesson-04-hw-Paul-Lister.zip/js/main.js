$(".sign-up-container").click(function() {
  alert("We're not ready for sign-ups...yet.");
});
