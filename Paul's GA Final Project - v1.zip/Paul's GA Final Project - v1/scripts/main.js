
$(document).ready(function(){
  $('#carousel').slick({
    //setting-name: setting-value

    dots: true,
  });
});

/* Will add functionality so when you click Contact on the Nav, page jumps down to footer */
/* Looking to add hamburger menu and responsive elements.
    Maybe also make it so the sidebar is responsive and fits under main head at certain breakpoint.
    Might add a simple toggle down or slider
     */




























/* Starting from https://developer.wordpress.com/
-It seems like I NEED to create a new client application, and therefore need a live website to apply to get client ID credentials for OAuth Authentication. There's a Basic Auth plugin in but you need to pay for Wordpress Business and Wordpress kind of sucks.

-They have a developer console to test stuff, but I can't get that to work right - https://developer.wordpress.com/docs/api/console/

-OAuth2 - I need to have an application registered to receive client ID needed to do anything here: https://developer.wordpress.com/docs/oauth2/ . Here's the application, but it looks like I need a live website to actually complete this - https://developer.wordpress.com/apps/new/ .

-There's info on Unauthenticated Requests, but the info provided isn't clear enough for me - https://developer.wordpress.com/docs/rest-api-javascript/ .
--I did get something to work in Postman using Basic Auth and my username/password for WP, it yielded a 200 OK status, with data, but I'm confused how to pull more specific data.

REST API Handbook reference for arguments for different calls - https://developer.wordpress.org/rest-api/reference/posts/#list-posts
*/


/*
$.ajax({
  type: 'GET',
  url: http://public-api.wordpress.com/rest/v1/sites/plister86.wordpress.com/?categories=Movies
})*/


/* What I might expect from an API call example with Wordpress with handling for a typical response you might get from Wordpress API

$.ajax({
  type: 'POST',
  url: 'https://wordpress.org/api/v2/your-endpoint'
  data: {
    settingOne: 'title',
    settingTwo: 'URL',
    settingThree: 'image',
    settingFour: 'summary'
  },
  success: function(result) {
    for (var i=0; i < result.length; i++) {
      $('#my-list-article-container').html('<div class="my-article-title">' + result[i].article.title + '</div>');
    }
  },
  error: function(result) {
    console.log(result);
  }
});

*/

/*
When I click on a tab from the Nav, such as "MOVIES", I want to be directed to the Movies page, which contains the most current list of articles with the tag or category "Movies" in Wordpress. When you land on this page, I want it to return the most recent list of Movies-related articles. */
